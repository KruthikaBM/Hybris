/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 14-Mar-2023, 12:51:25 PM                    ---
 * ----------------------------------------------------------------
 *  
 * Copyright (c) 2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
package de.hybris.myshoestore.facades.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedMyshoestoreFacadesConstants
{
	public static final String EXTENSIONNAME = "myshoestorefacades";
	
	protected GeneratedMyshoestoreFacadesConstants()
	{
		// private constructor
	}
	
	
}
