package de.hybris.myshoestore.facades.newproducts.impl;

import de.hybris.myshoestore.core.model.NewProductsModel;
import de.hybris.myshoestore.core.service.NewProductsService;
import de.hybris.myshoestore.facades.newproducts.NewProductsFacade;
import de.hybris.platform.commercefacades.product.data.NewProducts;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

public class NewProductsFacadeImpl implements NewProductsFacade {
    private NewProductsService newProductsService;
    @Required
    public void setNewProductsService(final NewProductsService newProductsService)
    {
     this.newProductsService = newProductsService;
}

    @Resource(name = "newProductsDataConverter")
    private Converter<NewProductsModel, NewProducts> newProductsDataConverter;
    private static final Logger LOG = Logger.getLogger(NewProductsFacadeImpl.class);

    @Override
    public List<NewProducts> getNewProductsDetails() {
        LOG.info("####################### newProductFacadeImpl ###################");
        final List<NewProducts> products = new ArrayList<NewProducts>();
        final List<NewProductsModel> model = newProductsService.getNewProductsDetails();
        final List<NewProducts> newProducts = newProductsDataConverter.convertAll(model);
        products.addAll(newProducts );
        return products;
    }
}
