package de.hybris.myshoestore.facades.newproducts;

import de.hybris.platform.commercefacades.product.data.NewProducts;

import java.util.List;

public interface NewProductsFacade {
    public List<NewProducts> getNewProductsDetails();
}
