package de.hybris.myshoestore.core.service;

import de.hybris.myshoestore.core.model.NewProductsModel;

import java.util.List;

public interface NewProductsService {
    public List<NewProductsModel> getNewProductsDetails();
}
