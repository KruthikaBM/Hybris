package de.hybris.myshoestore.core.dao.impl;

import de.hybris.myshoestore.core.dao.NewProductsDao;
import de.hybris.myshoestore.core.model.NewProductsModel;
import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;


import javax.annotation.Resource;
import java.util.List;




public class NewProductsDaoImpl implements NewProductsDao {

    private static final Logger LOG = Logger.getLogger(NewProductsDaoImpl.class);

    private FlexibleSearchService flexibleSearchService;

    @Required
    public void setFlexibleSearchService(final FlexibleSearchService flexibleSearchService) {
        this.flexibleSearchService = flexibleSearchService;
    }



    @Override
    //annotation resources
    public List<NewProductsModel> getNewProductsDetails() {
        LOG.info("NewProducts");
        String query="SELECT {PK} FROM {NewProducts}";
        FlexibleSearchQuery searchQuery=new FlexibleSearchQuery(query.toString());
        SearchResult<NewProductsModel> searchResult= flexibleSearchService.search(searchQuery);//getFlexibleSearchService
        return searchResult.getResult();
    }


}
