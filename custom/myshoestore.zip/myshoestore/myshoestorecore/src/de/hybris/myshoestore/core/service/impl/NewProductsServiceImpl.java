package de.hybris.myshoestore.core.service.impl;

import de.hybris.myshoestore.core.dao.NewProductsDao;
import de.hybris.myshoestore.core.model.NewProductsModel;
import de.hybris.myshoestore.core.service.NewProductsService;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class NewProductsServiceImpl implements NewProductsService {
    private NewProductsDao newProductsDao;
    private static final Logger LOG = Logger.getLogger(NewProductsServiceImpl.class);
    @Required
    public void setNewProductsDao(final NewProductsDao newProductsDao) {
        this.newProductsDao= newProductsDao;
    }

    @Override
    public List<NewProductsModel> getNewProductsDetails() {
        LOG.info("########################### NewProductsServiceImpl ###############");
        return newProductsDao.getNewProductsDetails();
    }
}
