package de.hybris.myshoestore.core.dao;

import de.hybris.myshoestore.core.model.NewProductsModel;

import java.util.List;

public interface NewProductsDao {
    public List<NewProductsModel> getNewProductsDetails();
}
